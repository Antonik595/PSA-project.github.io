function love.load()

end

function love.update(dt)

end

function love.draw()

end